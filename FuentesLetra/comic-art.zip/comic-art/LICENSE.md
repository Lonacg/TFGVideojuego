***Note of the author***

This demo font is for PERSONAL USE ONLY! But any donations are very appreciated.  
   
 Link to purchase full version and commercial license:  
 <https://justtheskills.com/product/comic-art/>  
   
 Please visit our store for more great fonts :  
 <https://justtheskills.com/vendor/pinisiart/>  
   
 Thank you